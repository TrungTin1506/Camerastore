<?php
include("sideBar.php");
?>

<div class="background">
</div>

<div class="boxInfo">
    <div class="container-info">
        <div class="Box1">
            <img src="../img/money-bag.png" alt="">
            <h2>Tổng giá trị đơn hàng</h2>
            <p>VNĐ 10.000.000</p>
        </div>
        <div class="Box2">
            <img src="../img/reciept.png" alt="">
            <h2>Số lượng đơn</h2>
            <p>200</p>
        </div>
        <div class="Box3">
            <img src="../img/login.png" alt="">
            <h2>Số lượng khách hàng</h2>
            <p>154</p>
        </div>
    </div>
</div>
<div class="top-sell">
    <div class="container-sell">
        <h2>Top sản phẩm bán chạy</h2>
        <table>
            <tr>
                <th></th>
                <th>Tên sản phẩm</th>
                <th>Số lượng</th>
                <th>Tổng giá trị</th>
            </tr>
            <tr>
                <th><img src="../img/canon/1500D-Kit/1500D-kit.png" alt=""></th>
                <th>Canon 1500D</th>
                <th>24</th>
                <th>300.000.000</th>
            </tr>
            <tr>
                <th><img src="../img/canon/1500D-Kit/1500D-kit.png" alt=""></th>
                <th>Canon 1500D</th>
                <th>24</th>
                <th>300.000.000</th>
            </tr>
            <tr>
                <th><img src="../img/canon/1500D-Kit/1500D-kit.png" alt=""></th>
                <th>Canon 1500D</th>
                <th>24</th>
                <th>300.000.000</th>
            </tr>
            <tr>
                <th><img src="../img/canon/1500D-Kit/1500D-kit.png" alt=""></th>
                <th>Canon 1500D</th>
                <th>24</th>
                <th>300.000.000</th>
            </tr>
        </table>
    </div>
</div>
</body>

</html>