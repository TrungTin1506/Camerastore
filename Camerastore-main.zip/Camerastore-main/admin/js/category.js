function displayAddBox() {
  document.getElementById("addProductModal").style.display = "block";
}

function closeAddBox() {
  document.getElementById("addProductModal").style.display = "none";
}

function closeEditBox() {
  document.getElementById("editProductModal").style.display = "none";
}
